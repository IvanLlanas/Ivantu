import { getRoundedCorners } from './corner_policy.js';

export class RoundedPipeline {
    constructor(effectsManager, getRadius, getCorners = () => 0) {
        this.effectsManager = effectsManager;
        this.getRadius = getRadius;
        this.getCorners = getCorners;
        this.pipeline = null;
        this.actor = null;
        this.effect = null;
        this.pipelineSignalIds = [];
        this.observedPipelineId = null;
        this.actorDestroyId = 0;
    }

    bind(pipeline, actor) {
        if (this.pipeline !== pipeline || this.actor !== actor)
            this.destroyExternalEffect();
        this.disconnectPipelineSignals();
        this.disconnectActorDestroy();
        this.pipeline = pipeline;
        this.actor = actor;
        this.actorDestroyId = actor.connect('destroy', () => {
            this.disconnectPipelineSignals();
            this.actorDestroyId = 0;
            this.effect = null;
            this.pipeline?.destroy();
            this.pipeline = null;
            this.actor = null;
        });
        this.update();
    }

    update() {
        if (!this.pipeline || !this.actor)
            return;

        this.syncPipelineSignals();

        const refractionEffects = this.getRefractionEffects();
        if (refractionEffects.length > 0) {
            this.destroyExternalEffect();
            this.updateRefractionCorners(refractionEffects);
            return;
        }

        // a blur drawn last cuts the corners in its own output, sparing a full-size pass
        const [outermostEffect] = this.pipeline.effects;
        if (outermostEffect?._bms_effect_type === 'dual_kawase_blur') {
            this.destroyExternalEffect();
            Object.assign(outermostEffect, {
                corner_radius: this.getRadius(),
                straight_corners: Boolean(this.straightCorners),
                ...getRoundedCorners(this.getCorners()),
            });
            return;
        }

        if (!this.effect) {
            this.effect = this.effectsManager.new_corner_effect({
                radius: this.getRadius(),
                straight_corners: Boolean(this.straightCorners),
                ...getRoundedCorners(this.getCorners()),
            });
            this.attachEffectAsOutermost(this.effect);
            return;
        }

        this.effect.radius = this.getRadius();
        this.effect.straight_corners = Boolean(this.straightCorners);
        Object.assign(this.effect, getRoundedCorners(this.getCorners()));
    }

    attachEffectAsOutermost(outermostEffect) {
        const existingEffects = this.pipeline?.effects ?? [];
        if (existingEffects[0] === outermostEffect)
            return;

        existingEffects.forEach(effect => this.actor.remove_effect(effect));
        this.actor.add_effect(outermostEffect);
        existingEffects.forEach(effect => {
            if (effect !== outermostEffect)
                this.actor.add_effect(effect);
        });

        if (existingEffects.includes(outermostEffect)) {
            this.pipeline.effects = [
                outermostEffect,
                ...existingEffects.filter(effect => effect !== outermostEffect),
            ];
        }
    }

    getRefractionEffects() {
        return this.pipeline.effects.filter(effect =>
            effect._bms_effect_type === 'refraction'
            && effect._bms_pixelize_role !== 'refraction-blur'
        );
    }

    updateRefractionCorners(effects = this.getRefractionEffects()) {
        const radius = this.straightCorners ? 0 : this.getRadius();
        effects.forEach(effect => {
            effect.corner_radius = radius;
            Object.assign(effect, getRoundedCorners(this.getCorners()));
        });
    }

    syncPipelineSignals(force = false) {
        const pipelineId = this.pipeline?.pipeline_id ?? null;
        if (!force && this.observedPipelineId === pipelineId)
            return;

        this.disconnectPipelineSignals();
        if (!pipelineId)
            return;

        const manager = this.pipeline.pipelines_manager;
        const refresh = () => {
            this.disconnectPipelineSignals();
            this.update();
        };
        this.pipelineSignalIds.push(
            manager.connect(`${pipelineId}::pipeline-updated`, refresh),
            manager.connect(`${pipelineId}::pipeline-destroyed`, refresh)
        );

        this.getRefractionEffects().forEach(effect => {
            const effectId = effect._bms_effect_id;
            if (!effectId)
                return;

            ['removed', 'updated', 'added'].forEach(change => {
                this.pipelineSignalIds.push(manager.connect(
                    `${pipelineId}::effect-${effectId}-key-${change}`,
                    (_, key) => {
                        if (key === 'corner_radius')
                            this.updateRefractionCorners();
                    }
                ));
            });
        });
        this.observedPipelineId = pipelineId;
    }

    disconnectPipelineSignals() {
        const manager = this.pipeline?.pipelines_manager;
        if (manager) {
            this.pipelineSignalIds.forEach(id => {
                if (id)
                    manager.disconnect(id);
            });
        }
        this.pipelineSignalIds = [];
        this.observedPipelineId = null;
    }

    disconnectActorDestroy() {
        if (this.actorDestroyId)
            this.actor.disconnect(this.actorDestroyId);
        this.actorDestroyId = 0;
    }

    setStraightCorners(straightCorners) {
        this.straightCorners = straightCorners;
        this.update();
    }

    destroyExternalEffect() {
        if (!this.effect)
            return;

        this.effectsManager.remove(this.effect);
        this.effect = null;
    }

    destroy() {
        this.disconnectPipelineSignals();
        this.disconnectActorDestroy();
        this.destroyExternalEffect();
        this.pipeline = null;
        this.actor = null;
    }
}
